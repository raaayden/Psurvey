<script setup>
        definePageMeta({
          title: "Survey Data",
        });
      </script>
      <template>
        <div>
          <LayoutsBreadcrumb />
        </div>
      </template>
      