<script setup>
  definePageMeta({
    title: "Survey Setting",
  });
  
  const project_name = ["","KLCC","MENARA AMBANK","TAPAK PASAR TTDI"];
  const parker_type = ["CASUAL", "SEASON"];
  const terminal_type = ["IN", "OUT"];

</script>

<template>
  <div>
    <LayoutsBreadcrumb />
    <rs-card class="p-5">
      <h3>Setting</h3>
      <br>
      <div class="card-body">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-x-4">
          <FormKit type="text" label="Type Project Name"/>
          <FormKit type="select" label="or Select Project Name" 
            :options="project_name"/>
          <FormKit type="date" :value="date" label="Date" />
          <FormKit type="text" label="Entry/ Exit Code"/>
          <FormKit type="radio" label="Parker Type"
            :options="parker_type"/>
            <FormKit type="radio" label="Terminal Type"
            :options="terminal_type"/>
          <FormKit type="text" label="Surveyor Name"/>
        </div>
        
      </div>
      <rs-button variant="success">Start Survey</rs-button>
    </rs-card>
  </div>

</template>
      